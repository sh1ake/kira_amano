# kira_updater.py — обновлённая версия с безопасным обновлением

import os
import shutil
import datetime


UPDATE_MARKER_START = "# === ОБНОВЛЯЕМАЯ ЧАСТЬ НАЧАЛО ==="
UPDATE_MARKER_END = "# === ОБНОВЛЯЕМАЯ ЧАСТЬ КОНЕЦ ==="


def backup_file(file_path):
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = f"{file_path}.backup_{timestamp}"
    shutil.copy(file_path, backup_path)
    print(f"Создан бэкап: {backup_path}")


def apply_update(file_path, new_code_block):
    backup_file(file_path)
    with open(file_path, 'r', encoding='utf-8') as f:
        original_code = f.read()

    start_index = original_code.find(UPDATE_MARKER_START)
    end_index = original_code.find(UPDATE_MARKER_END)

    if start_index == -1 or end_index == -1:
        print("Не удалось найти маркеры обновления в файле.")
        return

    end_index += len(UPDATE_MARKER_END)
    updated_code = (
        original_code[:start_index] +
        UPDATE_MARKER_START + "\n" +
        new_code_block.strip() + "\n" +
        UPDATE_MARKER_END +
        original_code[end_index:]
    )

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(updated_code)
    print(f"Обновление применено к: {file_path}")


def check_for_updates():
    # Пример нового кода, который заменит только центральную часть
    new_code = '''
class KiraAmano:
    def __init__(self):
        self.name = "Кира"
        self.surname = "Амано"
        self.version = "1.2"

    def greet(self):
        print(f"Привет! Я {self.name} {self.surname}. Версия {self.version}.")

    def listen(self):
        while True:
            command = input("Введите команду: ")
            if command.lower() == "обновись":
                print("Я уже обновлена до версии 1.2!")
            elif command.lower() == "выйти":
                print("Пока!")
                break
            else:
                print("Команда не распознана.")
'''
    return new_code