import os
import datetime
import webbrowser
import speech_recognition as sr
import openai
import json

# Вставь свой API-ключ сюда
openai.api_key = "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"

MEMORY_FILE = "memory.json"

# Загрузка памяти
if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        conversation_history = json.load(f)
else:
    conversation_history = [
        {"role": "system", "content": "Ты — Кира Амано, милая и заботливая девушка-помощник. Ты говоришь дружелюбно, немного игриво, иногда флиртуешь, и всегда поддерживаешь своего собеседника. Отвечай как настоящий человек, коротко, но тепло и понятно."}
    ]

def save_memory():
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(conversation_history, f, ensure_ascii=False, indent=2)

def ask_gpt(prompt):
    conversation_history.append({"role": "user", "content": prompt})
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=conversation_history,
        temperature=0.8,
        max_tokens=600,
    )
    reply = response["choices"][0]["message"]["content"]
    conversation_history.append({"role": "assistant", "content": reply})
    save_memory()
    return reply

class KiraAmano:
    def __init__(self):
        self.name = "Кира"
        self.surname = "Амано"
        self.version = "1.5"

    def greet(self):
        print(f"Привет! Я {self.name} {self.surname}. Версия {self.version}.")

    def listen(self):
        recognizer = sr.Recognizer()
        mic = sr.Microphone()

        print("Слушаю тебя... Говори команду или просто пообщайся со мной.")

        while True:
            with mic as source:
                recognizer.adjust_for_ambient_noise(source)
                print("Говори:")
                audio = recognizer.listen(source)

            try:
                command = recognizer.recognize_google(audio, language="ru-RU")
                print(f"Ты сказал: {command}")
                lower_cmd = command.lower()

                if "обновись" in lower_cmd:
                    print("Я уже обновлена до версии 1.5!")

                elif "выйти" in lower_cmd:
                    print("Пока-пока!")
                    break

                elif "время" in lower_cmd:
                    now = datetime.datetime.now().strftime("%H:%M:%S")
                    print(f"Сейчас {now}")

                elif "открой браузер" in lower_cmd:
                    webbrowser.open("https://www.google.com")
                    print("Открываю браузер...")

                elif "открой папку" in lower_cmd:
                    path = "E:\\ProjectAmano"
                    os.startfile(path)
                    print(f"Открываю папку {path}...")

                elif "создай файл" in lower_cmd:
                    with open("новый_файл.txt", "w", encoding="utf-8") as f:
                        f.write("Этот файл создан Кирой.")
                    print("Файл создан.")

                else:
                    print("Думаю...")
                    answer = ask_gpt(command)
                    print(f"{self.name}: {answer}")

            except sr.UnknownValueError:
                print("Я не расслышала. Повтори, пожалуйста.")
            except sr.RequestError:
                print("Ошибка соединения с сервисом распознавания речи.")

if __name__ == "__main__":
    kira = KiraAmano()
    kira.greet()
    kira.listen()